<?php
session_start();

$conn = new mysqli("localhost", "root", "", "votingsystem");

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
  echo "<script>alert('Unauthorized. Please log in.'); window.location.href = 'login.html';</script>";
  exit();
}

$user_id = $_SESSION['user_id'];
$candidate = $_POST['candidate'] ?? '';

$allowed_candidates = ['BJP', 'INC', 'AAP', 'BSP'];
if (!in_array($candidate, $allowed_candidates)) {
  echo "<script>alert('Invalid vote option.'); window.location.href = 'vote.php';</script>";
  exit();
}

$stmt = $conn->prepare("SELECT id FROM votes WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
  $stmt->close();
  $conn->close();
  echo "<script>alert('You have already voted.'); window.location.href = 'vote.php';</script>";
  exit();
}
$stmt->close();

$stmt = $conn->prepare("INSERT INTO votes (user_id, candidate) VALUES (?, ?)");
$stmt->bind_param("is", $user_id, $candidate);
$stmt->execute();
$stmt->close();
$conn->close();

echo "<script>alert('Thank you for voting!'); window.location.href = 'vote.php';</script>";
exit();
?>
