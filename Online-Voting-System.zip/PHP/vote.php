<?php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['username'])) {
  echo "<script>alert('Unauthorized access. Please log in.'); window.location.href = 'login.html';</script>";
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Vote - Online Voting System</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body style="background-image: url('1.jpg');">
  <header>
    <h1 class="slide-down">Online Voting System</h1>
    <div class="user-info">
      <span>Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></span>
      <form action="logout.php" method="POST" class="logout-form">
        <button type="submit" class="logout-btn">Logout</button>
      </form>
    </div>
  </header>

  <section class="centered-section vote-align-left">
    <div class="glass-form vote-box">
      <form action="submit_vote.php" method="POST">
        <h2>Cast Your Vote</h2>
        <div class= "party">

          <label class="vote-option">
            <input type="radio" name="candidate" value="BJP" required />
          <img src="bjp.jpg" alt="BJP" /> BJP
        </label>
        
        <label class="vote-option">
          <input type="radio" name="candidate" value="INC" required />
          <img src="inc.jpg" alt="INC" /> INC
        </label>
        
        <label class="vote-option">
          <input type="radio" name="candidate" value="AAP" required />
          <img src="aap.jpg" alt="AAP" /> AAP
        </label>
        
        <label class="vote-option">
          <input type="radio" name="candidate" value="BSP" required />
          <img src="bsp.jpg" alt="BSP" /> BSP
        </label>
      </div>
        
        <button type="submit">Submit Vote</button>
      </form>
    </div>
  </section>

  <footer>
    <p>&copy; 2025 Online Voting System | All Rights Reserved <br>Designed by Harshil Ranpariya</p>
  </footer>
</body>
</html>
