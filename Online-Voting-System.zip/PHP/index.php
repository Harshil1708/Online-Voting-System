<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Online Voting System</title>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- Font Awesome -->
</head>
<body>
  <header>
    <h1 class="slide-down">Online Voting System</h1>
    <nav>
      <ul>
        <!-- Show Login/Register links when the user is not logged in -->
        <?php if (!isset($_SESSION['username'])): ?>
          <li><a href="login.html">Login</a></li>
          <li><a href="register.html">Register</a></li>
        <?php else: ?>
          <!-- Show Logout when the user is logged in -->
          <li><a href="logout.php">Logout</a></li>
        <?php endif; ?>

        <div class="account">
            <ul>
                
                  

                  <a href="vote.php">
                      <li><i class="fa-solid fa-vote-yea"></i> Vote</li>
                  </a>

                  <a href="profile.php">
                      <li>
                          <i class="fa-solid fa-user" id="user-mb"></i>
                          <?php echo $_SESSION['username']; ?>
                      </li>
                  </a>
                <?php endif; ?>
            </ul>
        </div>
      </ul>
    </nav>
  </header>

  <section class="centered-section fade-in">
    <div class="welcome-box">
      <h2>Welcome!</h2>
      <p>Use your credentials to log in and cast your vote.</p>
    </div>
  </section>

  <footer>
    <p>&copy; 2025 Online Voting System | All Right Reserved <br>Designed by Harshil Ranpariya</p>
  </footer>
</body>
</html>
