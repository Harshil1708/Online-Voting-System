<?php
session_start();
$conn = new mysqli("localhost", "root", "", "votingsystem");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = $_POST['username'];
  $password = $_POST['password'];

  $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
  $stmt->bind_param("s", $username);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($id, $hash);
  $stmt->fetch();

  if ($stmt->num_rows > 0 && password_verify($password, $hash)) {
    $_SESSION['user_id'] = $id;
    $_SESSION['username'] = $username; 
    header("Location: vote.php");
    exit();
  } else {
    echo "<script>alert('Invalid credentials!'); window.location.href = 'login.html';</script>";
  }

  $stmt->close();
  $conn->close();
}
?>
