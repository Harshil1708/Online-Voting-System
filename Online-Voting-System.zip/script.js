function validatePasswords() {
  const password = document.getElementById("password").value;
  const confirm = document.getElementById("confirm_password").value;
  if (password !== confirm) {
    showPopup("Passwords do not match. Please enter the same password in both fields.");
    return false;
  }
  return true;
}

function showPopup(message, duration = 3000) {
  const popup = document.createElement("div");
  popup.className = "popup";
  popup.innerText = message;
  document.body.appendChild(popup);
  popup.style.display = "block";

  setTimeout(() => {
    popup.remove();
  }, duration);
}
